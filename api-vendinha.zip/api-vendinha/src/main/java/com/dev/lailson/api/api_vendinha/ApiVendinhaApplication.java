package com.dev.lailson.api.api_vendinha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiVendinhaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiVendinhaApplication.class, args);
	}

}
