package com.dev.lailson.api.api_vendinha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiVendinhaApplicationTests {

	@Test
	void contextLoads() {
	}

}
